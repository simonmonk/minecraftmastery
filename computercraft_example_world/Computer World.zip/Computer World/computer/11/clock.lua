local dateMon = peripheral.wrap("bottom")
local timeMon = peripheral.wrap("top")
timeMon.setTextScale(5)

dateMon.clear()
dateMon.write("14 November 2013")

timeMon.clear()
timeMon.setCursorPos(1, 0)
timeMon.write("10:46:01")
