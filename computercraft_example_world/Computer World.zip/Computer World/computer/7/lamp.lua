This could be a program, or any type of file.
