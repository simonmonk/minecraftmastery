rednet.open("right")
while true do
  id, message = rednet.receive(1)
  if (message == "on") then
    rs.setOutput("top", true)
  else
    rs.setOutput("top", false)
  end
  sleep(0.1)
end
