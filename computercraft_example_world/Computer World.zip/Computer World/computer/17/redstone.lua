turtle.refuel(1, 20)
turtle.select(2)
while true do
  turtle.forward()
  turtle.turnLeft()
  turtle.turnLeft()
  turtle.place()
  turtle.turnRight()
  turtle.turnRight()
end
