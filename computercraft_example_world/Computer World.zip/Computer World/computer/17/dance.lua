turtle.refuel(1, 10)

while true do
  turtle.forward()
  turtle.forward()
  turtle.forward()
  turtle.turnLeft()
end
